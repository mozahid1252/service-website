# Mozahidul Islam — Portfolio Website Setup Guide

## Step 1: Install Node.js & Bun
Download from: https://bun.sh

## Step 2: Extract & Install
```bash
unzip Mozahidul_Portfolio_SourceCode.zip
cd my-project
bun install
```

## Step 3: Setup Environment
```bash
cp .env.example .env
```
Edit `.env` and add your Gmail credentials:
- GMAIL_USER = your Gmail address
- GMAIL_APP_PASSWORD = your Gmail App Password (not regular password)
  Generate at: https://myaccount.google.com/apppasswords

## Step 4: Setup Database
```bash
bun run db:push
```

## Step 5: Run the Website
```bash
bun run dev
```
Open http://localhost:3000 in your browser.

## What's Included
- Complete Next.js 16 source code
- All images (photos + logo)
- All PDF files (resume, packages, case studies)
- Database schema (Prisma/SQLite)
- Contact form with Gmail SMTP
- Dark premium theme with animations

## Tech Stack
- Next.js 16 + TypeScript
- Tailwind CSS 4
- Prisma ORM + SQLite
- Lucide Icons
